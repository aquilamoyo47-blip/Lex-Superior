/**
 * ZimLII Scraper Configuration
 */

export const ZIMLII_CONFIG = {
  BASE_URL: 'https://zimlii.org',
  SEARCH_URL: 'https://zimlii.org/akn/search',
  DOCUMENT_URL: 'https://zimlii.org',
  REQUEST_TIMEOUT: 15000, // 15 seconds
  MAX_RETRIES: 3,
  DEFAULT_LIMIT: 10,
  MAX_LIMIT: 50,
  DELAY_MIN: 2000, // 2 seconds
  DELAY_MAX: 5000, // 5 seconds
} as const;

// User-Agent rotation pool for anti-detection
export const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
  'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
  'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:121.0) Gecko/20100101 Firefox/121.0',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 OPR/105.0.0.0',
  'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
];

// Available legal document categories on ZimLII
export const LEGAL_CATEGORIES = [
  { id: 'judgment', name: 'Judgments', description: 'Court judgments and rulings' },
  { id: 'legislation', name: 'Legislation', description: 'Acts, statutes, and regulations' },
  { id: 'constitutional', name: 'Constitutional Law', description: 'Constitutional matters and human rights' },
  { id: 'criminal', name: 'Criminal Law', description: 'Criminal cases and proceedings' },
  { id: 'civil', name: 'Civil Procedure', description: 'Civil litigation and procedure' },
  { id: 'commercial', name: 'Commercial Law', description: 'Business, corporate, and commercial matters' },
  { id: 'labour', name: 'Labour Law', description: 'Employment and labour disputes' },
  { id: 'family', name: 'Family Law', description: 'Family, marriage, and divorce matters' },
  { id: 'land', name: 'Land Law', description: 'Property and land disputes' },
  { id: 'tax', name: 'Tax Law', description: 'Tax and revenue matters' },
  { id: 'administrative', name: 'Administrative Law', description: 'Administrative and public law' },
  { id: 'environmental', name: 'Environmental Law', description: 'Environmental and natural resources' },
  { id: 'mining', name: 'Mining Law', description: 'Mining and mineral resources' },
  { id: 'banking', name: 'Banking & Finance', description: 'Banking and financial regulations' },
  { id: 'insurance', name: 'Insurance Law', description: 'Insurance and risk management' },
  { id: 'intellectual-property', name: 'Intellectual Property', description: 'Patents, trademarks, and copyrights' },
] as const;

// Court types
export const COURT_TYPES = [
  'Supreme Court of Zimbabwe',
  'High Court of Zimbabwe',
  'Constitutional Court of Zimbabwe',
  'Labour Court of Zimbabwe',
  'Administrative Court of Zimbabwe',
  'Magistrates Court',
] as const;

export type LegalCategory = (typeof LEGAL_CATEGORIES)[number]['id'];
export type CourtType = (typeof COURT_TYPES)[number];
