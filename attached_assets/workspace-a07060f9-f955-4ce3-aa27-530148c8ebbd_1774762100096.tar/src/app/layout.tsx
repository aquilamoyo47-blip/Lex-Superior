import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "ZimLII Search - Zimbabwe Legal Information Institute API",
  description: "Search and access Zimbabwean legal documents, judgments, legislation, and court rulings. Open access API for researchers, journalists, and citizens.",
  keywords: ["ZimLII", "Zimbabwe", "legal", "law", "judgments", "legislation", "courts", "API", "Civil Procedure", "Criminal Law"],
  authors: [{ name: "ZimLII Search" }],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
  openGraph: {
    title: "ZimLII Search - Zimbabwe Legal Information",
    description: "Open access to Zimbabwean legal documents, judgments, and legislation",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "ZimLII Search - Zimbabwe Legal Information",
    description: "Open access to Zimbabwean legal documents, judgments, and legislation",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
