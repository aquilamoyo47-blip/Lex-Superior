'use client';

import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { motion, AnimatePresence, useInView } from 'framer-motion';
import { toast } from 'sonner';
import {
  Search,
  Scale,
  BookOpen,
  FileText,
  Building2,
  Clock,
  ArrowRight,
  ExternalLink,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  Filter,
  X,
  Loader2,
  AlertCircle,
  RefreshCw,
  Menu,
  Globe,
  Gavel,
  Shield,
  Briefcase,
  Landmark,
  Home as HomeIcon,
  TreePine,
  Banknote,
  Building,
  HardHat,
  Lock,
  Copyright,
  Heart,
  Zap,
  TrendingUp,
  Hash,
  CalendarDays,
  User,
  BadgeCheck,
  Info,
  Bookmark,
  BookmarkCheck,
  Copy,
  Download,
  Share2,
  List,
  LayoutList,
  ArrowUp,
  SlidersHorizontal,
  Trash2,
  Command,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Tooltip, TooltipContent, TooltipTrigger, TooltipProvider } from '@/components/ui/tooltip';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

// --- Types ---

interface DocumentResult {
  id: string;
  title: string;
  url: string;
  date?: string;
  court?: string;
  citation?: string;
  docketNumber?: string;
  judges?: string[];
  documentType?: string;
  jurisdiction: string;
  snippet?: string;
}

interface SearchResults {
  query: string;
  category?: string;
  results: DocumentResult[];
  totalResults?: number;
  page: number;
  limit: number;
  cached: boolean;
  timestamp: string;
  sortBy?: string;
  stats?: {
    byCourt?: Record<string, number>;
    byType?: Record<string, number>;
  };
}

interface Category {
  id: string;
  name: string;
  description: string;
}

interface DocumentDetail {
  id: string;
  title: string;
  url: string;
  date?: string;
  court?: string;
  citation?: string;
  docketNumber?: string;
  judges?: string[];
  documentType?: string;
  jurisdiction: string;
  content?: string;
  htmlContent?: string;
  metadata: Record<string, string>;
  cached: boolean;
  timestamp: string;
}

interface SearchHistoryItem {
  query: string;
  category: string | null;
  timestamp: number;
}

interface BookmarkItem {
  id: string;
  title: string;
  url: string;
  court?: string;
  date?: string;
  citation?: string;
  documentType?: string;
  jurisdiction: string;
  snippet?: string;
  judges?: string[];
  docketNumber?: string;
  bookmarkedAt: number;
}

// --- Category Icons Mapping ---

const categoryIcons: Record<string, React.ReactNode> = {
  judgment: <Gavel className="h-5 w-5" />,
  legislation: <BookOpen className="h-5 w-5" />,
  constitutional: <Shield className="h-5 w-5" />,
  criminal: <Scale className="h-5 w-5" />,
  civil: <Briefcase className="h-5 w-5" />,
  commercial: <Building className="h-5 w-5" />,
  labour: <HardHat className="h-5 w-5" />,
  family: <Heart className="h-5 w-5" />,
  land: <Landmark className="h-5 w-5" />,
  tax: <Banknote className="h-5 w-5" />,
  administrative: <HomeIcon className="h-5 w-5" />,
  environmental: <TreePine className="h-5 w-5" />,
  mining: <HardHat className="h-5 w-5" />,
  banking: <Building className="h-5 w-5" />,
  insurance: <Shield className="h-5 w-5" />,
  'intellectual-property': <Lock className="h-5 w-5" />,
};

// --- Constants ---

const COURTS = [
  'All Courts',
  'Supreme Court of Zimbabwe',
  'High Court of Zimbabwe',
  'Constitutional Court of Zimbabwe',
  'Labour Court of Zimbabwe',
  'Administrative Court of Zimbabwe',
];

const DOC_TYPES = [
  'All Types',
  'Judgment',
  'Legislation',
  'Constitutional Case',
  'Labour Judgment',
  'Administrative Review',
];

const SORT_OPTIONS = [
  { value: 'date-desc', label: 'Newest First' },
  { value: 'date-asc', label: 'Oldest First' },
  { value: 'relevance', label: 'Relevance' },
];

const QUICK_SEARCHES = [
  { label: 'Civil Procedure', query: 'civil procedure' },
  { label: 'Criminal Appeal', query: 'criminal appeal' },
  { label: 'Constitutional Rights', query: 'constitutional rights' },
  { label: 'Labour Dispute', query: 'labour dispute' },
  { label: 'Land Acquisition', query: 'land acquisition' },
  { label: 'Tax Law', query: 'tax assessment' },
];

// --- Utility ---

function formatDate(dateStr?: string): string {
  if (!dateStr) return 'N/A';
  try {
    return new Date(dateStr).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

function truncateText(text: string, maxLen: number = 200): string {
  if (text.length <= maxLen) return text;
  return text.slice(0, maxLen).trim() + '...';
}

// --- localStorage helpers ---

function getSearchHistory(): SearchHistoryItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('zimlii-search-history');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function addSearchHistory(query: string, category: string | null) {
  if (!query || query.trim().length === 0) return;
  try {
    const history = getSearchHistory();
    const filtered = history.filter(
      (h) => !(h.query === query && h.category === category)
    );
    filtered.unshift({ query, category, timestamp: Date.now() });
    localStorage.setItem(
      'zimlii-search-history',
      JSON.stringify(filtered.slice(0, 8))
    );
  } catch {
    // ignore
  }
}

function clearSearchHistory() {
  try {
    localStorage.removeItem('zimlii-search-history');
  } catch {
    // ignore
  }
}

function getBookmarks(): BookmarkItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('zimlii-bookmarks');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function toggleBookmark(doc: DocumentResult): BookmarkItem[] {
  try {
    const bookmarks = getBookmarks();
    const idx = bookmarks.findIndex((b) => b.id === doc.id);
    if (idx >= 0) {
      bookmarks.splice(idx, 1);
    } else {
      bookmarks.unshift({
        id: doc.id,
        title: doc.title,
        url: doc.url,
        court: doc.court,
        date: doc.date,
        citation: doc.citation,
        documentType: doc.documentType,
        jurisdiction: doc.jurisdiction,
        snippet: doc.snippet,
        judges: doc.judges,
        docketNumber: doc.docketNumber,
        bookmarkedAt: Date.now(),
      });
    }
    localStorage.setItem('zimlii-bookmarks', JSON.stringify(bookmarks));
    return bookmarks;
  } catch {
    return getBookmarks();
  }
}

function isBookmarked(docId: string): boolean {
  return getBookmarks().some((b) => b.id === docId);
}

// --- Animated Counter Component ---

function AnimatedCounter({
  target,
  suffix = '',
  prefix = '',
  duration = 2,
}: {
  target: number;
  suffix?: string;
  prefix?: string;
  duration?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true });
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let start = 0;
    const step = Math.ceil(target / (duration * 60));
    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(start);
      }
    }, 1000 / 60);
    return () => clearInterval(timer);
  }, [inView, target, duration]);

  return (
    <span ref={ref}>
      {prefix}
      {count.toLocaleString()}
      {suffix}
    </span>
  );
}

// --- Main Application ---

export default function Home() {
  // State
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [searchResults, setSearchResults] = useState<SearchResults | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [selectedDocument, setSelectedDocument] = useState<DocumentDetail | null>(null);
  const [isLoadingDocument, setIsLoadingDocument] = useState(false);
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [hasSearched, setHasSearched] = useState(false);
  const [searchInputFocused, setSearchInputFocused] = useState(false);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);
  const heroRef = useRef<HTMLElement>(null);

  // Enhancement: View toggle
  const [viewMode, setViewMode] = useState<'list' | 'compact'>('list');

  // Enhancement: Advanced filters
  const [filterCourt, setFilterCourt] = useState('All Courts');
  const [filterDocType, setFilterDocType] = useState('All Types');
  const [sortBy, setSortBy] = useState('date-desc');
  const [showAdvancedFilters, setShowAdvancedFilters] = useState(false);

  // Enhancement: Search history & Bookmarks
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);
  const [bookmarks, setBookmarks] = useState<BookmarkItem[]>([]);
  const [activeTab, setActiveTab] = useState<'search' | 'bookmarks'>('search');

  // Enhancement: Back to top
  const [showBackToTop, setShowBackToTop] = useState(false);

  // Fetch categories on mount
  useEffect(() => {
    async function fetchCategories() {
      try {
        const res = await fetch('/api/categories');
        if (res.ok) {
          const data = await res.json();
          setCategories(data.categories);
        }
      } catch (err) {
        console.error('Failed to fetch categories:', err);
      }
    }
    fetchCategories();
  }, []);

  // Load search history and bookmarks on mount
  useEffect(() => {
    setSearchHistory(getSearchHistory());
    setBookmarks(getBookmarks());
  }, []);

  // Enhancement: Keyboard shortcuts
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      // Cmd+K / Ctrl+K to focus search
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        searchInputRef.current?.focus();
      }
      // Escape to clear search and close dialogs
      if (e.key === 'Escape') {
        if (selectedDocument) {
          setSelectedDocument(null);
          setIsLoadingDocument(false);
        } else if (showMobileFilters) {
          setShowMobileFilters(false);
        } else {
          setQuery('');
          searchInputRef.current?.blur();
        }
      }
    }
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedDocument, showMobileFilters]);

  // Enhancement: Back to top scroll detection
  useEffect(() => {
    function handleScroll() {
      if (!heroRef.current) return;
      const heroBottom = heroRef.current.getBoundingClientRect().bottom;
      setShowBackToTop(heroBottom < 0);
    }
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Search function
  const performSearch = useCallback(
    async (searchQuery: string, category?: string) => {
      if (!searchQuery && !category) return;

      setIsLoading(true);
      setError(null);
      setHasSearched(true);
      setActiveTab('search');

      try {
        const params = new URLSearchParams();
        if (searchQuery) params.set('q', searchQuery);
        if (category) params.set('category', category);
        if (filterCourt !== 'All Courts') params.set('court', filterCourt);
        if (filterDocType !== 'All Types') params.set('type', filterDocType);
        params.set('sort', sortBy);

        const res = await fetch(`/api/search?${params.toString()}`);
        if (!res.ok) {
          const errData = await res.json();
          throw new Error(errData.message || 'Search failed');
        }
        const data: SearchResults = await res.json();
        setSearchResults(data);

        // Save to search history
        addSearchHistory(searchQuery, category || null);
        setSearchHistory(getSearchHistory());

        // Scroll to results
        setTimeout(() => {
          resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 100);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'An unexpected error occurred');
      } finally {
        setIsLoading(false);
      }
    },
    [filterCourt, filterDocType, sortBy]
  );

  // Fetch document detail
  const fetchDocumentDetail = useCallback(async (doc: DocumentResult) => {
    setIsLoadingDocument(true);
    setSelectedDocument(null);

    try {
      const res = await fetch(`/api/document/${encodeURIComponent(doc.url)}`);
      if (!res.ok) throw new Error('Failed to fetch document');
      const data: DocumentDetail = await res.json();
      setSelectedDocument(data);
    } catch (err) {
      console.error('Document detail error:', err);
    } finally {
      setIsLoadingDocument(false);
    }
  }, []);

  // Handle search form submit
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    performSearch(query, selectedCategory || undefined);
  };

  // Handle category click
  const handleCategoryClick = (category: Category) => {
    const newCategory = selectedCategory === category.id ? null : category.id;
    setSelectedCategory(newCategory);
    setShowMobileFilters(false);
    if (newCategory || query) {
      performSearch(query, newCategory || undefined);
    }
  };

  // Enhancement: Bookmark toggle handler
  const handleToggleBookmark = (e: React.MouseEvent, doc: DocumentResult) => {
    e.stopPropagation();
    const updated = toggleBookmark(doc);
    setBookmarks([...updated]);
    const wasBookmarked = isBookmarked(doc.id);
    if (!wasBookmarked) {
      toast.success('Bookmark added', {
        description: `"${truncateText(doc.title, 50)}" bookmarked`,
      });
    } else {
      toast('Bookmark removed', {
        description: `"${truncateText(doc.title, 50)}" removed from bookmarks`,
      });
    }
  };

  // Enhancement: Export functions
  const exportToJSON = () => {
    if (!searchResults?.results.length) return;
    const data = searchResults.results.map((doc) => ({
      title: doc.title,
      url: doc.url,
      court: doc.court,
      date: doc.date,
      citation: doc.citation,
      docketNumber: doc.docketNumber,
      judges: doc.judges,
      documentType: doc.documentType,
      jurisdiction: doc.jurisdiction,
      snippet: doc.snippet,
    }));
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zimlii-search-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('JSON downloaded', { description: 'Search results exported as JSON' });
  };

  const exportToCSV = () => {
    if (!searchResults?.results.length) return;
    const headers = ['Title', 'Court', 'Date', 'Citation', 'Type', 'Jurisdiction', 'URL'];
    const rows = searchResults.results.map((doc) => [
      `"${(doc.title || '').replace(/"/g, '""')}"`,
      `"${(doc.court || '').replace(/"/g, '""')}"`,
      `"${doc.date || ''}"`,
      `"${(doc.citation || '').replace(/"/g, '""')}"`,
      `"${(doc.documentType || '').replace(/"/g, '""')}"`,
      `"${(doc.jurisdiction || '').replace(/"/g, '""')}"`,
      `"${doc.url}"`,
    ]);
    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `zimlii-search-${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success('CSV downloaded', { description: 'Search results exported as CSV' });
  };

  const copyResultsToClipboard = async () => {
    if (!searchResults?.results.length) return;
    const data = searchResults.results.map((doc) => ({
      title: doc.title,
      court: doc.court,
      date: doc.date,
      citation: doc.citation,
      url: doc.url,
    }));
    try {
      await navigator.clipboard.writeText(JSON.stringify(data, null, 2));
      toast.success('Copied to clipboard', { description: 'Search results copied as JSON' });
    } catch {
      toast.error('Failed to copy', { description: 'Could not copy to clipboard' });
    }
  };

  // Enhancement: Copy citation
  const copyCitation = async () => {
    if (!selectedDocument?.citation) return;
    try {
      await navigator.clipboard.writeText(selectedDocument.citation);
      toast.success('Citation copied', { description: selectedDocument.citation });
    } catch {
      toast.error('Failed to copy', { description: 'Could not copy citation' });
    }
  };

  // Enhancement: Share document
  const shareDocument = async () => {
    if (!selectedDocument) return;
    const shareData = {
      title: selectedDocument.title,
      text: `${selectedDocument.title} - ${selectedDocument.citation || selectedDocument.court || ''}`,
      url: selectedDocument.url,
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(selectedDocument.url);
        toast.success('Link copied', { description: 'Document URL copied to clipboard' });
      }
    } catch (err) {
      if ((err as Error).name !== 'AbortError') {
        try {
          await navigator.clipboard.writeText(selectedDocument.url);
          toast.success('Link copied', { description: 'Document URL copied to clipboard' });
        } catch {
          toast.error('Failed to share', { description: 'Could not share or copy the link' });
        }
      }
    }
  };

  // Enhancement: Clear search history
  const handleClearHistory = () => {
    clearSearchHistory();
    setSearchHistory([]);
    toast('Search history cleared');
  };

  // Bookmark count for header
  const bookmarkCount = bookmarks.length;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-xl">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-primary text-primary-foreground">
                <Scale className="h-5 w-5" />
              </div>
              <div className="hidden sm:block">
                <h1 className="text-lg font-bold leading-tight">ZimLII Search</h1>
                <p className="text-xs text-muted-foreground leading-tight">
                  Zimbabwe Legal Information Institute
                </p>
              </div>
              <div className="sm:hidden">
                <h1 className="text-lg font-bold leading-tight">ZimLII</h1>
              </div>
            </div>

            {/* Status */}
            <div className="flex items-center gap-2">
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Badge variant="secondary" className="hidden sm:flex items-center gap-1.5">
                      <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                      API Active
                    </Badge>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>ZimLII search API is operational</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              {/* Bookmark button in header */}
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Button
                      variant="outline"
                      size="sm"
                      className="relative items-center gap-1.5"
                      onClick={() => {
                        setActiveTab(activeTab === 'bookmarks' ? 'search' : 'bookmarks');
                        if (activeTab !== 'bookmarks') {
                          setSearchResults(null);
                          setHasSearched(false);
                          setError(null);
                          resultsRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
                        }
                      }}
                    >
                      <Bookmark className="h-4 w-4" />
                      <span className="hidden sm:inline text-xs">Bookmarks</span>
                      {bookmarkCount > 0 && (
                        <span className="absolute -top-1.5 -right-1.5 h-4 w-4 rounded-full bg-primary text-primary-foreground text-[10px] flex items-center justify-center font-bold">
                          {bookmarkCount > 9 ? '9+' : bookmarkCount}
                        </span>
                      )}
                    </Button>
                  </TooltipTrigger>
                  <TooltipContent>
                    <p>View bookmarks ({bookmarkCount})</p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>

              {/* Mobile filter toggle */}
              <Button
                variant="outline"
                size="icon"
                className="lg:hidden"
                onClick={() => setShowMobileFilters(!showMobileFilters)}
              >
                <Menu className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {/* Hero Section */}
        <section ref={heroRef} className="relative overflow-hidden border-b">
          {/* Background gradient */}
          <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-primary/5" />
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/3 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />

          <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 lg:py-20">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="text-center max-w-3xl mx-auto"
            >
              <Badge variant="outline" className="mb-4">
                <Globe className="h-3 w-3 mr-1.5" />
                Open Access to Zimbabwean Law
              </Badge>

              <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight mb-4">
                Search Zimbabwe&apos;s Legal
                <span className="text-primary"> Database</span>
              </h2>

              <p className="text-muted-foreground text-base sm:text-lg mb-8 max-w-2xl mx-auto">
                Access judgments, legislation, and legal documents from Zimbabwe&apos;s courts.{' '}
                Search across Civil Procedure, Criminal Law, Constitutional Law, and more.
              </p>

              {/* Search Form */}
              <form onSubmit={handleSearch} className="relative max-w-2xl mx-auto">
                <div
                  className={`relative flex items-center rounded-xl border-2 bg-card shadow-lg transition-all ${
                    searchInputFocused
                      ? 'border-primary shadow-primary/10'
                      : 'border-border'
                  }`}
                >
                  <Search className="absolute left-4 h-5 w-5 text-muted-foreground" />
                  <Input
                    ref={searchInputRef}
                    type="text"
                    placeholder="Search for judgments, cases, legislation..."
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    onFocus={() => setSearchInputFocused(true)}
                    onBlur={() => setSearchInputFocused(false)}
                    className="pl-12 pr-32 py-6 text-base rounded-xl border-0 focus-visible:ring-0"
                  />
                  <div className="absolute right-2 flex items-center gap-2">
                    {selectedCategory && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="text-xs"
                        onClick={() => {
                          setSelectedCategory(null);
                          if (query) performSearch(query);
                        }}
                      >
                        <X className="h-3 w-3 mr-1" />
                        {categories.find((c) => c.id === selectedCategory)?.name}
                      </Button>
                    )}
                    <Button
                      type="submit"
                      disabled={isLoading || (!query && !selectedCategory)}
                      className="rounded-lg"
                    >
                      {isLoading ? (
                        <Loader2 className="h-4 w-4 animate-spin" />
                      ) : (
                        <>
                          Search
                          <ArrowRight className="h-4 w-4 ml-1.5" />
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {/* Keyboard shortcut hint */}
                <div className="flex items-center justify-center mt-2">
                  <kbd className="pointer-events-none inline-flex h-5 select-none items-center gap-1 rounded border bg-muted px-1.5 font-mono text-[10px] font-medium text-muted-foreground opacity-60">
                    <Command className="h-3 w-3" />K
                  </kbd>
                  <span className="text-[10px] text-muted-foreground ml-1.5 opacity-60">
                    to focus search
                  </span>
                </div>
              </form>

              {/* Quick Search Tags */}
              <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
                <span className="text-xs text-muted-foreground mr-1">Try:</span>
                {QUICK_SEARCHES.map((s) => (
                  <Button
                    key={s.label}
                    variant="outline"
                    size="sm"
                    className="text-xs h-7"
                    onClick={() => {
                      setQuery(s.query);
                      setSelectedCategory(null);
                      performSearch(s.query);
                    }}
                  >
                    {s.label}
                  </Button>
                ))}
              </div>

              {/* Enhancement: Search History Tags */}
              {searchHistory.length > 0 && (
                <div className="mt-4">
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-xs text-muted-foreground">Recent:</span>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {searchHistory.slice(0, 6).map((h, i) => (
                        <Button
                          key={`${h.query}-${h.category}-${i}`}
                          variant="secondary"
                          size="sm"
                          className="text-xs h-6 px-2"
                          onClick={() => {
                            setQuery(h.query);
                            setSelectedCategory(h.category);
                            performSearch(h.query, h.category || undefined);
                          }}
                        >
                          <Clock className="h-2.5 w-2.5 mr-1" />
                          {h.query}
                        </Button>
                      ))}
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs h-6 px-2 text-muted-foreground hover:text-destructive"
                        onClick={handleClearHistory}
                      >
                        <Trash2 className="h-2.5 w-2.5 mr-1" />
                        Clear
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              {/* Enhancement: Animated Hero Stats */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-10 max-w-2xl mx-auto">
                {[
                  { value: 25000, suffix: '+', prefix: '', label: 'Legal Documents', icon: <BookOpen className="h-5 w-5" />, color: 'text-emerald-500' },
                  { value: 16, suffix: '', prefix: '', label: 'Practice Areas', icon: <Scale className="h-5 w-5" />, color: 'text-amber-500' },
                  { value: 6, suffix: '', prefix: '', label: 'Court Types', icon: <Landmark className="h-5 w-5" />, color: 'text-rose-500' },
                  { value: 1, suffix: '', prefix: 'Updated ', label: 'Daily', icon: <Clock className="h-5 w-5" />, color: 'text-cyan-500' },
                ].map((stat) => (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: 0.6 }}
                    className="flex flex-col items-center gap-1"
                  >
                    <div className={`flex items-center gap-2 ${stat.color}`}>
                      {stat.icon}
                      <span className="text-2xl font-bold">
                        {stat.label === 'Updated Daily' ? (
                          <span>Updated Daily</span>
                        ) : (
                          <AnimatedCounter target={stat.value} suffix={stat.suffix} prefix={stat.prefix} />
                        )}
                      </span>
                    </div>
                    <span className="text-xs text-muted-foreground">{stat.label}</span>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* Content Section */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="flex gap-8">
            {/* Sidebar - Categories (Desktop) */}
            <aside className="hidden lg:block w-72 flex-shrink-0">
              <div className="sticky top-24">
                {/* Legal Categories */}
                <div className="flex items-center gap-2 mb-4">
                  <Filter className="h-4 w-4 text-muted-foreground" />
                  <h3 className="font-semibold text-sm">Legal Categories</h3>
                </div>
                <ScrollArea className="h-[calc(100vh-450px)]">
                  <div className="space-y-1 pr-4">
                    {/* All categories button */}
                    <button
                      onClick={() => {
                        setSelectedCategory(null);
                        if (hasSearched) performSearch(query);
                      }}
                      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors text-left ${
                        !selectedCategory
                          ? 'bg-primary text-primary-foreground'
                          : 'hover:bg-accent text-foreground'
                      }`}
                    >
                      <FileText className="h-4 w-4 flex-shrink-0" />
                      <div className="min-w-0 flex-1">
                        <div className="font-medium">All Categories</div>
                      </div>
                    </button>

                    <Separator className="my-2" />

                    {categories.map((cat) => (
                      <button
                        key={cat.id}
                        onClick={() => handleCategoryClick(cat)}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-colors text-left group ${
                          selectedCategory === cat.id
                            ? 'bg-primary text-primary-foreground'
                            : 'hover:bg-accent text-foreground'
                        }`}
                      >
                        <div className="flex-shrink-0">
                          {categoryIcons[cat.id] || <FileText className="h-4 w-4" />}
                        </div>
                        <div className="min-w-0 flex-1">
                          <div className="font-medium">{cat.name}</div>
                          <div
                            className={`text-xs mt-0.5 ${
                              selectedCategory === cat.id
                                ? 'text-primary-foreground/80'
                                : 'text-muted-foreground'
                            }`}
                          >
                            {cat.description}
                          </div>
                        </div>
                        {selectedCategory === cat.id && (
                          <ChevronRight className="h-4 w-4 flex-shrink-0" />
                        )}
                      </button>
                    ))}
                  </div>
                </ScrollArea>

                {/* Enhancement: Advanced Filters Panel */}
                <div className="mt-6">
                  <button
                    onClick={() => setShowAdvancedFilters(!showAdvancedFilters)}
                    className="flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-foreground transition-colors w-full"
                  >
                    <SlidersHorizontal className="h-4 w-4" />
                    Advanced Filters
                    {showAdvancedFilters ? (
                      <ChevronUp className="h-4 w-4 ml-auto" />
                    ) : (
                      <ChevronDown className="h-4 w-4 ml-auto" />
                    )}
                  </button>

                  <AnimatePresence>
                    {showAdvancedFilters && (
                      <motion.div
                        initial={{ height: 0, opacity: 0 }}
                        animate={{ height: 'auto', opacity: 1 }}
                        exit={{ height: 0, opacity: 0 }}
                        transition={{ duration: 0.2 }}
                        className="overflow-hidden"
                      >
                        <div className="space-y-3 mt-3">
                          <div>
                            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                              Court
                            </label>
                            <Select value={filterCourt} onValueChange={(v) => { setFilterCourt(v); if (hasSearched) performSearch(query, selectedCategory || undefined); }}>
                              <SelectTrigger className="w-full text-xs">
                                <SelectValue placeholder="All Courts" />
                              </SelectTrigger>
                              <SelectContent>
                                {COURTS.map((court) => (
                                  <SelectItem key={court} value={court} className="text-xs">
                                    {court}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                              Document Type
                            </label>
                            <Select value={filterDocType} onValueChange={(v) => { setFilterDocType(v); if (hasSearched) performSearch(query, selectedCategory || undefined); }}>
                              <SelectTrigger className="w-full text-xs">
                                <SelectValue placeholder="All Types" />
                              </SelectTrigger>
                              <SelectContent>
                                {DOC_TYPES.map((type) => (
                                  <SelectItem key={type} value={type} className="text-xs">
                                    {type}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          <div>
                            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">
                              Sort By
                            </label>
                            <Select value={sortBy} onValueChange={(v) => { setSortBy(v); if (hasSearched) performSearch(query, selectedCategory || undefined); }}>
                              <SelectTrigger className="w-full text-xs">
                                <SelectValue placeholder="Sort" />
                              </SelectTrigger>
                              <SelectContent>
                                {SORT_OPTIONS.map((opt) => (
                                  <SelectItem key={opt.value} value={opt.value} className="text-xs">
                                    {opt.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                          </div>

                          {(filterCourt !== 'All Courts' || filterDocType !== 'All Types' || sortBy !== 'date-desc') && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="w-full text-xs text-muted-foreground"
                              onClick={() => {
                                setFilterCourt('All Courts');
                                setFilterDocType('All Types');
                                setSortBy('date-desc');
                                if (hasSearched) performSearch(query, selectedCategory || undefined);
                              }}
                            >
                              <X className="h-3 w-3 mr-1" />
                              Reset Filters
                            </Button>
                          )}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </aside>

            {/* Mobile Category Drawer */}
            <AnimatePresence>
              {showMobileFilters && (
                <motion.div
                  initial={{ opacity: 0, x: -300 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -300 }}
                  className="fixed inset-0 z-50 lg:hidden"
                >
                  <div
                    className="absolute inset-0 bg-black/50"
                    onClick={() => setShowMobileFilters(false)}
                  />
                  <div className="absolute left-0 top-0 bottom-0 w-80 bg-background p-4 shadow-xl overflow-y-auto">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Legal Categories</h3>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => setShowMobileFilters(false)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                    <div className="space-y-1">
                      <button
                        onClick={() => {
                          setSelectedCategory(null);
                          setShowMobileFilters(false);
                          if (hasSearched) performSearch(query);
                        }}
                        className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-left ${
                          !selectedCategory
                            ? 'bg-primary text-primary-foreground'
                            : 'hover:bg-accent'
                        }`}
                      >
                        <FileText className="h-4 w-4" />
                        All Categories
                      </button>
                      {categories.map((cat) => (
                        <button
                          key={cat.id}
                          onClick={() => handleCategoryClick(cat)}
                          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-left ${
                            selectedCategory === cat.id
                              ? 'bg-primary text-primary-foreground'
                              : 'hover:bg-accent'
                          }`}
                        >
                          {categoryIcons[cat.id] || <FileText className="h-4 w-4" />}
                          <div>
                            <div className="font-medium">{cat.name}</div>
                            <div
                              className={`text-xs ${
                                selectedCategory === cat.id
                                  ? 'text-primary-foreground/80'
                                  : 'text-muted-foreground'
                              }`}
                            >
                              {cat.description}
                            </div>
                          </div>
                        </button>
                      ))}
                    </div>

                    {/* Mobile Advanced Filters */}
                    <Separator className="my-4" />
                    <h4 className="font-semibold text-sm mb-3 flex items-center gap-2">
                      <SlidersHorizontal className="h-4 w-4" />
                      Filters
                    </h4>
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Court</label>
                        <Select value={filterCourt} onValueChange={(v) => { setFilterCourt(v); }}>
                          <SelectTrigger className="w-full text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {COURTS.map((court) => (
                              <SelectItem key={court} value={court} className="text-xs">{court}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Document Type</label>
                        <Select value={filterDocType} onValueChange={(v) => { setFilterDocType(v); }}>
                          <SelectTrigger className="w-full text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {DOC_TYPES.map((type) => (
                              <SelectItem key={type} value={type} className="text-xs">{type}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Sort By</label>
                        <Select value={sortBy} onValueChange={(v) => { setSortBy(v); }}>
                          <SelectTrigger className="w-full text-xs">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            {SORT_OPTIONS.map((opt) => (
                              <SelectItem key={opt.value} value={opt.value} className="text-xs">{opt.label}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Main Content */}
            <div className="flex-1 min-w-0" ref={resultsRef}>
              {/* Tab header for search vs bookmarks */}
              {hasSearched && (
                <div className="flex items-center gap-4 mb-6">
                  <button
                    onClick={() => { setActiveTab('search'); }}
                    className={`text-sm font-medium pb-1 border-b-2 transition-colors ${
                      activeTab === 'search'
                        ? 'border-primary text-foreground'
                        : 'border-transparent text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    Search Results
                  </button>
                  <button
                    onClick={() => { setActiveTab('bookmarks'); setSearchResults(null); setError(null); setIsLoading(false); }}
                    className={`text-sm font-medium pb-1 border-b-2 transition-colors flex items-center gap-1.5 ${
                      activeTab === 'bookmarks'
                        ? 'border-primary text-foreground'
                        : 'border-transparent text-muted-foreground hover:text-foreground'
                    }`}
                  >
                    <Bookmark className="h-3.5 w-3.5" />
                    Bookmarks
                    {bookmarkCount > 0 && (
                      <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-4">
                        {bookmarkCount}
                      </Badge>
                    )}
                  </button>
                </div>
              )}

              {/* Bookmarks Tab */}
              {activeTab === 'bookmarks' && !searchResults && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-lg font-semibold">Bookmarked Documents</h3>
                    {bookmarks.length > 0 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        className="text-xs text-muted-foreground hover:text-destructive"
                        onClick={() => {
                          try { localStorage.removeItem('zimlii-bookmarks'); } catch { /* ignore */ }
                          setBookmarks([]);
                          toast('All bookmarks cleared');
                        }}
                      >
                        <Trash2 className="h-3 w-3 mr-1" />
                        Clear All
                      </Button>
                    )}
                  </div>
                  {bookmarks.length === 0 ? (
                    <div className="text-center py-12">
                      <div className="flex items-center justify-center h-16 w-16 rounded-full bg-muted mx-auto mb-4">
                        <Bookmark className="h-8 w-8 text-muted-foreground" />
                      </div>
                      <h4 className="font-semibold mb-1">No Bookmarks Yet</h4>
                      <p className="text-sm text-muted-foreground max-w-sm mx-auto">
                        Search for documents and click the bookmark icon to save them for later.
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-3 max-h-[600px] overflow-y-auto">
                      {bookmarks.map((bmk, idx) => (
                        <motion.div
                          key={bmk.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: idx * 0.03 }}
                        >
                          <Card
                            className="hover:shadow-md transition-all cursor-pointer group border-border/60 hover:border-primary/30"
                            onClick={() => fetchDocumentDetail(bmk as DocumentResult)}
                          >
                            <CardContent className="p-4">
                              <div className="flex items-start gap-3">
                                <div className="flex items-center justify-center h-8 w-8 rounded-lg bg-primary/10 text-primary flex-shrink-0">
                                  {bmk.documentType?.includes('Legislation') ? (
                                    <BookOpen className="h-4 w-4" />
                                  ) : (
                                    <Scale className="h-4 w-4" />
                                  )}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <h4 className="font-semibold text-sm leading-snug group-hover:text-primary transition-colors">
                                    {bmk.title}
                                  </h4>
                                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs text-muted-foreground">
                                    {bmk.court && <span>{bmk.court}</span>}
                                    {bmk.date && <span>{formatDate(bmk.date)}</span>}
                                    {bmk.citation && <span>{bmk.citation}</span>}
                                  </div>
                                </div>
                                <Button
                                  variant="ghost"
                                  size="icon"
                                  className="h-8 w-8 text-primary flex-shrink-0"
                                  onClick={(e) => handleToggleBookmark(e, bmk as DocumentResult)}
                                >
                                  <BookmarkCheck className="h-4 w-4 fill-primary" />
                                </Button>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {/* Loading State */}
              {isLoading && activeTab === 'search' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-4"
                >
                  <div className="flex items-center gap-3 mb-6">
                    <Loader2 className="h-5 w-5 animate-spin text-primary" />
                    <p className="text-sm text-muted-foreground">Searching legal documents...</p>
                  </div>
                  {[1, 2, 3, 4].map((i) => (
                    <Card key={i}>
                      <CardContent className="p-6">
                        <div className="space-y-3">
                          <Skeleton className="h-5 w-3/4" />
                          <Skeleton className="h-4 w-1/2" />
                          <Skeleton className="h-3 w-full" />
                          <Skeleton className="h-3 w-5/6" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </motion.div>
              )}

              {/* Error State */}
              {error && !isLoading && activeTab === 'search' && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                >
                  <Card className="border-destructive/50 bg-destructive/5">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-3">
                        <AlertCircle className="h-5 w-5 text-destructive mt-0.5 flex-shrink-0" />
                        <div>
                          <h3 className="font-semibold text-destructive">Search Error</h3>
                          <p className="text-sm text-muted-foreground mt-1">{error}</p>
                          <Button
                            variant="outline"
                            size="sm"
                            className="mt-3"
                            onClick={() => performSearch(query, selectedCategory || undefined)}
                          >
                            <RefreshCw className="h-3 w-3 mr-1.5" />
                            Try Again
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              )}

              {/* Results */}
              {!isLoading && searchResults && activeTab === 'search' && (
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 0.3 }}
                >
                  {/* Results Header */}
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
                    <div>
                      <h3 className="text-lg font-semibold">
                        {searchResults.results.length > 0
                          ? 'Search Results'
                          : 'No Results Found'}
                      </h3>
                      <p className="text-sm text-muted-foreground">
                        {searchResults.results.length > 0
                          ? `Found ${searchResults.results.length} document${searchResults.results.length !== 1 ? 's' : ''} matching "${searchResults.query || searchResults.category || 'all'}"`
                          : `No documents found for "${searchResults.query || searchResults.category || 'all'}". Try adjusting your search terms.`}
                      </p>
                    </div>
                    {searchResults.results.length > 0 && (
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Enhancement: View Toggle */}
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant={viewMode === 'list' ? 'default' : 'outline'}
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => setViewMode('list')}
                              >
                                <List className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent><p>List view</p></TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant={viewMode === 'compact' ? 'default' : 'outline'}
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => setViewMode('compact')}
                              >
                                <LayoutList className="h-4 w-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent><p>Compact view</p></TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <Separator orientation="vertical" className="h-6 mx-1" />

                        {/* Enhancement: Export Dropdown */}
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="outline" size="sm" className="text-xs h-8">
                              <Download className="h-3 w-3 mr-1.5" />
                              Export
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuLabel className="text-xs">Export Results</DropdownMenuLabel>
                            <DropdownMenuSeparator />
                            <DropdownMenuItem className="text-xs" onClick={copyResultsToClipboard}>
                              <Copy className="h-3 w-3 mr-2" />
                              Copy to Clipboard
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-xs" onClick={exportToJSON}>
                              <Download className="h-3 w-3 mr-2" />
                              Download JSON
                            </DropdownMenuItem>
                            <DropdownMenuItem className="text-xs" onClick={exportToCSV}>
                              <Download className="h-3 w-3 mr-2" />
                              Download CSV
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>

                        {/* Filter/sort badges */}
                        {searchResults.cached && (
                          <Badge variant="secondary" className="text-xs">
                            <Zap className="h-3 w-3 mr-1" />
                            Cached
                          </Badge>
                        )}
                        {selectedCategory && (
                          <Badge variant="outline" className="text-xs">
                            {categories.find((c) => c.id === selectedCategory)?.name}
                          </Badge>
                        )}
                        {filterCourt !== 'All Courts' && (
                          <Badge variant="outline" className="text-xs">
                            {filterCourt}
                          </Badge>
                        )}
                        {filterDocType !== 'All Types' && (
                          <Badge variant="outline" className="text-xs">
                            {filterDocType}
                          </Badge>
                        )}
                        <Badge variant="secondary" className="text-xs">
                          <Clock className="h-3 w-3 mr-1" />
                          {new Date(searchResults.timestamp).toLocaleTimeString()}
                        </Badge>
                      </div>
                    )}
                  </div>

                  {/* Enhancement: Results Statistics */}
                  {searchResults.results.length > 0 && searchResults.stats && (
                    (searchResults.stats.byCourt || searchResults.stats.byType) && (
                      <Card className="mb-4 bg-muted/30">
                        <CardContent className="p-3">
                          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                            <span className="font-medium text-foreground text-xs">Breakdown:</span>
                            {searchResults.stats.byCourt &&
                              Object.entries(searchResults.stats.byCourt).map(([court, count]) => (
                                <span key={court}>
                                  {court}: <span className="font-medium text-foreground">{count}</span>
                                </span>
                              ))}
                            {searchResults.stats.byType &&
                              Object.entries(searchResults.stats.byType).map(([type, count]) => (
                                <span key={type}>
                                  {type}: <span className="font-medium text-foreground">{count}</span>
                                </span>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    )
                  )}

                  {/* Results List - List View */}
                  {viewMode === 'list' && (
                    <div className="space-y-3">
                      {searchResults.results.map((doc, idx) => (
                        <motion.div
                          key={doc.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, delay: idx * 0.05 }}
                        >
                          <Card
                            className="hover:shadow-md transition-all cursor-pointer group border-border/60 hover:border-primary/30"
                            onClick={() => fetchDocumentDetail(doc)}
                          >
                            <CardContent className="p-5 sm:p-6">
                              <div className="flex items-start gap-4">
                                {/* Document Type Icon */}
                                <div className="hidden sm:flex items-center justify-center h-10 w-10 rounded-lg bg-primary/10 text-primary flex-shrink-0 mt-0.5">
                                  {doc.documentType?.includes('Legislation') ? (
                                    <BookOpen className="h-5 w-5" />
                                  ) : (
                                    <Scale className="h-5 w-5" />
                                  )}
                                </div>

                                {/* Content */}
                                <div className="flex-1 min-w-0">
                                  {/* Title */}
                                  <div className="flex items-start justify-between gap-2">
                                    <h4 className="font-semibold text-base leading-snug group-hover:text-primary transition-colors">
                                      {doc.title}
                                    </h4>
                                    {/* Enhancement: Bookmark button */}
                                    <Button
                                      variant="ghost"
                                      size="icon"
                                      className="h-8 w-8 flex-shrink-0 hover:bg-primary/10"
                                      onClick={(e) => handleToggleBookmark(e, doc)}
                                    >
                                      {isBookmarked(doc.id) ? (
                                        <BookmarkCheck className="h-4 w-4 text-primary fill-primary" />
                                      ) : (
                                        <Bookmark className="h-4 w-4 text-muted-foreground" />
                                      )}
                                    </Button>
                                  </div>

                                  {/* Metadata Row */}
                                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-2 text-xs text-muted-foreground">
                                    {doc.court && (
                                      <span className="flex items-center gap-1">
                                        <Building2 className="h-3 w-3" />
                                        {doc.court}
                                      </span>
                                    )}
                                    {doc.date && (
                                      <span className="flex items-center gap-1">
                                        <CalendarDays className="h-3 w-3" />
                                        {formatDate(doc.date)}
                                      </span>
                                    )}
                                    {doc.citation && (
                                      <span className="flex items-center gap-1">
                                        <Hash className="h-3 w-3" />
                                        {doc.citation}
                                      </span>
                                    )}
                                    {doc.docketNumber && (
                                      <span className="flex items-center gap-1">
                                        <BadgeCheck className="h-3 w-3" />
                                        {doc.docketNumber}
                                      </span>
                                    )}
                                  </div>

                                  {/* Judges */}
                                  {doc.judges && doc.judges.length > 0 && (
                                    <div className="flex items-center gap-1 mt-1.5 text-xs text-muted-foreground">
                                      <User className="h-3 w-3" />
                                      <span>{doc.judges.join(', ')}</span>
                                    </div>
                                  )}

                                  {/* Snippet */}
                                  {doc.snippet && (
                                    <p className="mt-3 text-sm text-muted-foreground leading-relaxed">
                                      {truncateText(doc.snippet, 250)}
                                    </p>
                                  )}

                                  {/* Badges */}
                                  <div className="flex flex-wrap items-center gap-2 mt-3">
                                    {doc.documentType && (
                                      <Badge variant="outline" className="text-xs font-normal">
                                        {doc.documentType}
                                      </Badge>
                                    )}
                                    <Badge variant="secondary" className="text-xs font-normal">
                                      <Globe className="h-2.5 w-2.5 mr-1" />
                                      {doc.jurisdiction}
                                    </Badge>
                                    <span className="text-xs text-muted-foreground ml-auto flex items-center gap-1 group-hover:text-primary">
                                      View Details
                                      <ExternalLink className="h-3 w-3" />
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {/* Results List - Compact View */}
                  {viewMode === 'compact' && (
                    <div className="space-y-1">
                      {searchResults.results.map((doc, idx) => (
                        <motion.div
                          key={doc.id}
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          transition={{ duration: 0.15, delay: idx * 0.03 }}
                        >
                          <div
                            className="flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-accent/50 cursor-pointer group transition-colors border border-transparent hover:border-border/60"
                            onClick={() => fetchDocumentDetail(doc)}
                          >
                            <div className="hidden sm:flex items-center justify-center h-7 w-7 rounded bg-primary/10 text-primary flex-shrink-0">
                              {doc.documentType?.includes('Legislation') ? (
                                <BookOpen className="h-3.5 w-3.5" />
                              ) : (
                                <Scale className="h-3.5 w-3.5" />
                              )}
                            </div>
                            <div className="flex-1 min-w-0 flex items-center gap-3">
                              <span className="text-sm font-medium truncate group-hover:text-primary transition-colors">
                                {doc.title}
                              </span>
                              <span className="text-xs text-muted-foreground hidden md:inline flex-shrink-0">
                                {doc.court}
                              </span>
                              <span className="text-xs text-muted-foreground hidden lg:inline flex-shrink-0">
                                {doc.date ? formatDate(doc.date) : ''}
                              </span>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-7 w-7 flex-shrink-0 hover:bg-primary/10"
                              onClick={(e) => handleToggleBookmark(e, doc)}
                            >
                              {isBookmarked(doc.id) ? (
                                <BookmarkCheck className="h-3.5 w-3.5 text-primary fill-primary" />
                              ) : (
                                <Bookmark className="h-3.5 w-3.5 text-muted-foreground" />
                              )}
                            </Button>
                            <ExternalLink className="h-3 w-3 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0" />
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </motion.div>
              )}

              {/* Empty State - Before Search (Enhanced) */}
              {!isLoading && !searchResults && !error && activeTab === 'search' && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 }}
                  className="text-center py-12"
                >
                  {/* Enhancement: Creative law-themed illustration */}
                  <div className="relative inline-flex items-center justify-center mb-6">
                    <div className="absolute h-24 w-24 rounded-full bg-primary/5" />
                    <div className="absolute h-20 w-20 rounded-full bg-primary/10" />
                    <div className="relative flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 shadow-sm">
                      <Scale className="h-8 w-8 text-primary" />
                    </div>
                    <Gavel className="absolute -top-1 -right-4 h-6 w-6 text-amber-500 opacity-60" />
                    <BookOpen className="absolute -bottom-1 -left-3 h-5 w-5 text-emerald-500 opacity-60" />
                    <Shield className="absolute top-0 -left-5 h-5 w-5 text-rose-500 opacity-60" />
                  </div>

                  <h3 className="text-lg font-semibold mb-2">Search Zimbabwe&apos;s Legal Database</h3>
                  <p className="text-sm text-muted-foreground max-w-md mx-auto mb-8">
                    Enter a search term above or select a legal category to explore Zimbabwean
                    judgments, legislation, and legal documents.
                  </p>

                  {/* Enhancement: Popular Searches as styled cards */}
                  <div className="mb-10">
                    <h4 className="text-sm font-semibold mb-4 text-muted-foreground uppercase tracking-wider">
                      Popular Searches
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 max-w-3xl mx-auto text-left">
                      <Card
                        className="border-dashed cursor-pointer hover:border-primary/30 hover:shadow-md transition-all group"
                        onClick={() => {
                          setQuery('civil procedure');
                          setSelectedCategory('civil');
                          performSearch('civil procedure', 'civil');
                        }}
                      >
                        <CardContent className="p-5">
                          <div className="h-9 w-9 rounded-lg bg-emerald-100 text-emerald-600 dark:bg-emerald-950 dark:text-emerald-400 flex items-center justify-center mb-3">
                            <TrendingUp className="h-5 w-5" />
                          </div>
                          <h4 className="font-medium text-sm mb-1 group-hover:text-primary transition-colors">Civil Procedure</h4>
                          <p className="text-xs text-muted-foreground">
                            Access civil litigation rulings, procedural judgments, and court directives.
                          </p>
                        </CardContent>
                      </Card>
                      <Card
                        className="border-dashed cursor-pointer hover:border-primary/30 hover:shadow-md transition-all group"
                        onClick={() => {
                          setQuery('criminal appeal');
                          setSelectedCategory('criminal');
                          performSearch('criminal appeal', 'criminal');
                        }}
                      >
                        <CardContent className="p-5">
                          <div className="h-9 w-9 rounded-lg bg-amber-100 text-amber-600 dark:bg-amber-950 dark:text-amber-400 flex items-center justify-center mb-3">
                            <Scale className="h-5 w-5" />
                          </div>
                          <h4 className="font-medium text-sm mb-1 group-hover:text-primary transition-colors">Criminal Law</h4>
                          <p className="text-xs text-muted-foreground">
                            Search criminal cases, appeals, and sentencing decisions from all courts.
                          </p>
                        </CardContent>
                      </Card>
                      <Card
                        className="border-dashed cursor-pointer hover:border-primary/30 hover:shadow-md transition-all group"
                        onClick={() => {
                          setQuery('constitutional rights');
                          setSelectedCategory('constitutional');
                          performSearch('constitutional rights', 'constitutional');
                        }}
                      >
                        <CardContent className="p-5">
                          <div className="h-9 w-9 rounded-lg bg-rose-100 text-rose-600 dark:bg-rose-950 dark:text-rose-400 flex items-center justify-center mb-3">
                            <Shield className="h-5 w-5" />
                          </div>
                          <h4 className="font-medium text-sm mb-1 group-hover:text-primary transition-colors">Constitutional Law</h4>
                          <p className="text-xs text-muted-foreground">
                            Find constitutional matters, human rights cases, and landmark rulings.
                          </p>
                        </CardContent>
                      </Card>
                      <Card
                        className="border-dashed cursor-pointer hover:border-primary/30 hover:shadow-md transition-all group"
                        onClick={() => {
                          setQuery('labour dispute');
                          setSelectedCategory('labour');
                          performSearch('labour dispute', 'labour');
                        }}
                      >
                        <CardContent className="p-5">
                          <div className="h-9 w-9 rounded-lg bg-cyan-100 text-cyan-600 dark:bg-cyan-950 dark:text-cyan-400 flex items-center justify-center mb-3">
                            <Briefcase className="h-5 w-5" />
                          </div>
                          <h4 className="font-medium text-sm mb-1 group-hover:text-primary transition-colors">Labour Law</h4>
                          <p className="text-xs text-muted-foreground">
                            Browse labour disputes, unfair dismissal cases, and employment law rulings.
                          </p>
                        </CardContent>
                      </Card>
                      <Card
                        className="border-dashed cursor-pointer hover:border-primary/30 hover:shadow-md transition-all group"
                        onClick={() => {
                          setQuery('land acquisition');
                          setSelectedCategory('land');
                          performSearch('land acquisition', 'land');
                        }}
                      >
                        <CardContent className="p-5">
                          <div className="h-9 w-9 rounded-lg bg-orange-100 text-orange-600 dark:bg-orange-950 dark:text-orange-400 flex items-center justify-center mb-3">
                            <Landmark className="h-5 w-5" />
                          </div>
                          <h4 className="font-medium text-sm mb-1 group-hover:text-primary transition-colors">Land Law</h4>
                          <p className="text-xs text-muted-foreground">
                            Find land acquisition, property disputes, and land reform cases.
                          </p>
                        </CardContent>
                      </Card>
                      <Card
                        className="border-dashed cursor-pointer hover:border-primary/30 hover:shadow-md transition-all group"
                        onClick={() => {
                          setQuery('tax assessment');
                          setSelectedCategory('tax');
                          performSearch('tax assessment', 'tax');
                        }}
                      >
                        <CardContent className="p-5">
                          <div className="h-9 w-9 rounded-lg bg-violet-100 text-violet-600 dark:bg-violet-950 dark:text-violet-400 flex items-center justify-center mb-3">
                            <Banknote className="h-5 w-5" />
                          </div>
                          <h4 className="font-medium text-sm mb-1 group-hover:text-primary transition-colors">Tax Law</h4>
                          <p className="text-xs text-muted-foreground">
                            Access tax legislation, assessments, and revenue authority decisions.
                          </p>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </motion.div>
              )}
            </div>
          </div>
        </div>

        {/* Civil Procedure Spotlight Section */}
        <section className="border-t bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-8">
              <Badge variant="outline" className="mb-3">
                <Gavel className="h-3 w-3 mr-1" />
                Featured Category
              </Badge>
              <h2 className="text-2xl sm:text-3xl font-bold">Civil Procedure</h2>
              <p className="text-muted-foreground mt-2 max-w-2xl mx-auto">
                Civil Procedure is one of the most frequently accessed areas of Zimbabwean law.
                Browse recent judgments and procedural rulings from the High Court and Supreme Court.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                {
                  title: 'Summary Judgment Applications',
                  desc: 'Applications for summary judgment in civil disputes',
                  query: 'summary judgment',
                },
                {
                  title: 'Default Judgments',
                  desc: 'Judgments entered in the absence of the defendant',
                  query: 'default judgment',
                },
                {
                  title: 'Interdict Applications',
                  desc: 'Urgent interdict and injunction relief',
                  query: 'interdict application',
                },
                {
                  title: 'Review Applications',
                  desc: 'Review of administrative decisions and actions',
                  query: 'review application',
                },
                {
                  title: 'Appeal Proceedings',
                  desc: 'Civil appeals from lower courts',
                  query: 'civil appeal',
                },
                {
                  title: 'Discovery & Pleadings',
                  desc: 'Discovery applications and pleadings compliance',
                  query: 'discovery',
                },
              ].map((item) => (
                <Card
                  key={item.query}
                  className="cursor-pointer hover:shadow-md transition-all hover:border-primary/30 group"
                  onClick={() => {
                    setQuery(item.query);
                    setSelectedCategory('civil');
                    setActiveTab('search');
                    performSearch(item.query, 'civil');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                >
                  <CardContent className="p-5">
                    <h3 className="font-semibold text-sm group-hover:text-primary transition-colors flex items-center gap-2">
                      {item.title}
                      <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </h3>
                    <p className="text-xs text-muted-foreground mt-1">{item.desc}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* API Documentation Section */}
        <section className="border-t">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
            <div className="text-center mb-8">
              <h2 className="text-2xl font-bold">API Endpoints</h2>
              <p className="text-muted-foreground mt-2">
                Programmatic access to ZimLII search functionality
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-4xl mx-auto">
              {[
                {
                  method: 'GET',
                  path: '/api/health',
                  desc: 'Health check - returns API status and cache statistics',
                  example: 'curl /api/health',
                },
                {
                  method: 'GET',
                  path: '/api/categories',
                  desc: 'List all available legal document categories',
                  example: 'curl /api/categories',
                },
                {
                  method: 'GET',
                  path: '/api/search?q={query}&category={category}',
                  desc: 'Search legal documents by query and category',
                  example: 'curl "/api/search?q=civil+procedure&category=civil"',
                },
                {
                  method: 'GET',
                  path: '/api/document/{id}',
                  desc: 'Retrieve full details of a specific document',
                  example: 'curl "/api/document/{document-url}"',
                },
              ].map((endpoint) => (
                <Card key={endpoint.path}>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge
                        variant={endpoint.method === 'GET' ? 'default' : 'secondary'}
                        className="text-xs font-mono"
                      >
                        {endpoint.method}
                      </Badge>
                      <code className="text-xs font-mono text-muted-foreground truncate">
                        {endpoint.path}
                      </code>
                    </div>
                    <p className="text-xs text-muted-foreground">{endpoint.desc}</p>
                    <div className="mt-2 px-3 py-2 rounded bg-muted text-xs font-mono overflow-x-auto">
                      {endpoint.example}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Enhancement: Back to Top Button */}
      <AnimatePresence>
        {showBackToTop && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            transition={{ duration: 0.2 }}
            className="fixed bottom-6 right-6 z-40"
          >
            <TooltipProvider>
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    size="icon"
                    className="h-10 w-10 rounded-full shadow-lg"
                    onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
                  >
                    <ArrowUp className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent>
                  <p>Back to top</p>
                </TooltipContent>
              </Tooltip>
            </TooltipProvider>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Document Detail Dialog */}
      <Dialog
        open={!!selectedDocument || isLoadingDocument}
        onOpenChange={(open) => {
          if (!open) {
            setSelectedDocument(null);
            setIsLoadingDocument(false);
          }
        }}
      >
        <DialogContent className="max-w-3xl max-h-[85vh] overflow-hidden flex flex-col p-0">
          {isLoadingDocument ? (
            <div className="p-6">
              <div className="flex items-center gap-3 mb-6">
                <Loader2 className="h-5 w-5 animate-spin text-primary" />
                <span>Loading document...</span>
              </div>
              <div className="space-y-3">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <Skeleton className="h-3 w-full" />
                <Skeleton className="h-3 w-5/6" />
                <Skeleton className="h-3 w-4/6" />
              </div>
            </div>
          ) : selectedDocument ? (
            <>
              <DialogHeader className="p-6 pb-0">
                <DialogTitle className="text-lg leading-snug pr-8">
                  {selectedDocument.title}
                </DialogTitle>
                <DialogDescription className="sr-only">
                  Document details for {selectedDocument.title}
                </DialogDescription>
              </DialogHeader>

              <ScrollArea className="flex-1">
                <div className="px-6 pb-6">
                  {/* Metadata */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-6 mt-2">
                    {selectedDocument.court && (
                      <div className="flex items-center gap-2 text-sm">
                        <Building2 className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-muted-foreground">Court:</span>
                        <span className="font-medium">{selectedDocument.court}</span>
                      </div>
                    )}
                    {selectedDocument.date && (
                      <div className="flex items-center gap-2 text-sm">
                        <CalendarDays className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-muted-foreground">Date:</span>
                        <span className="font-medium">{formatDate(selectedDocument.date)}</span>
                      </div>
                    )}
                    {selectedDocument.citation && (
                      <div className="flex items-center gap-2 text-sm">
                        <Hash className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-muted-foreground">Citation:</span>
                        <span className="font-medium">{selectedDocument.citation}</span>
                      </div>
                    )}
                    {selectedDocument.docketNumber && (
                      <div className="flex items-center gap-2 text-sm">
                        <BadgeCheck className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-muted-foreground">Docket:</span>
                        <span className="font-medium">{selectedDocument.docketNumber}</span>
                      </div>
                    )}
                    {selectedDocument.documentType && (
                      <div className="flex items-center gap-2 text-sm">
                        <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                        <span className="text-muted-foreground">Type:</span>
                        <Badge variant="outline" className="text-xs font-normal">
                          {selectedDocument.documentType}
                        </Badge>
                      </div>
                    )}
                    <div className="flex items-center gap-2 text-sm">
                      <Globe className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                      <span className="text-muted-foreground">Jurisdiction:</span>
                      <span className="font-medium">{selectedDocument.jurisdiction}</span>
                    </div>
                  </div>

                  {/* Judges */}
                  {selectedDocument.judges && selectedDocument.judges.length > 0 && (
                    <div className="mb-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-2">
                        <User className="h-4 w-4" />
                        <span>Bench</span>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {selectedDocument.judges.map((judge, i) => (
                          <Badge key={i} variant="secondary" className="text-xs">
                            {judge}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}

                  <Separator className="my-4" />

                  {/* Content */}
                  {selectedDocument.content ? (
                    <div>
                      <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                        <FileText className="h-4 w-4" />
                        Document Content
                      </h4>
                      <div className="prose prose-sm max-w-none dark:prose-invert text-sm leading-relaxed whitespace-pre-wrap text-foreground/80">
                        {truncateText(selectedDocument.content, 3000)}
                        {selectedDocument.content.length > 3000 && (
                          <span className="text-muted-foreground block mt-2">
                            ... Content truncated.{' '}
                            <a
                              href={selectedDocument.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-primary hover:underline"
                            >
                              Read full document on ZimLII
                            </a>
                          </span>
                        )}
                      </div>
                    </div>
                  ) : selectedDocument.metadata && Object.keys(selectedDocument.metadata).length > 0 ? (
                    <div>
                      <h4 className="text-sm font-semibold mb-3 flex items-center gap-2">
                        <Info className="h-4 w-4" />
                        Document Metadata
                      </h4>
                      <div className="space-y-2">
                        {Object.entries(selectedDocument.metadata).map(([key, value]) => (
                          <div key={key} className="flex items-start gap-2 text-sm">
                            <span className="text-muted-foreground font-medium min-w-[120px]">
                              {key}:
                            </span>
                            <span>{value}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-sm text-muted-foreground">
                        Document content is available on the ZimLII website.
                      </p>
                    </div>
                  )}

                  {/* Footer Actions */}
                  <Separator className="my-4" />
                  <div className="flex items-center justify-between flex-wrap gap-3">
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      {selectedDocument.cached && (
                        <Badge variant="secondary" className="text-xs">
                          <Zap className="h-3 w-3 mr-1" />
                          Cached
                        </Badge>
                      )}
                      <span>
                        Retrieved: {new Date(selectedDocument.timestamp).toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {/* Enhancement: Copy Citation button */}
                      {selectedDocument.citation && (
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="outline"
                                size="sm"
                                className="text-xs"
                                onClick={copyCitation}
                              >
                                <Copy className="h-3 w-3 mr-1.5" />
                                Copy Citation
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent><p>Copy citation to clipboard</p></TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      )}

                      {/* Enhancement: Share button */}
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button
                              variant="outline"
                              size="sm"
                              className="text-xs"
                              onClick={shareDocument}
                            >
                              <Share2 className="h-3 w-3 mr-1.5" />
                              Share
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent><p>Share this document</p></TooltipContent>
                        </Tooltip>
                      </TooltipProvider>

                      <Button variant="outline" size="sm" asChild>
                        <a
                          href={selectedDocument.url}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <ExternalLink className="h-3 w-3 mr-1.5" />
                          Open on ZimLII
                        </a>
                      </Button>
                    </div>
                  </div>
                </div>
              </ScrollArea>
            </>
          ) : null}
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <footer className="border-t bg-muted/30 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Scale className="h-4 w-4" />
              <span>ZimLII Search API &mdash; Open Access to Zimbabwean Law</span>
            </div>
            <div className="flex items-center gap-4 text-xs text-muted-foreground">
              <span>Data sourced from zimlii.org</span>
              <span>&bull;</span>
              <span>Built with Next.js</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
