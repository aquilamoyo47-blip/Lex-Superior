import { NextResponse } from 'next/server';
import { getAllSampleDocuments, getCourtsList } from '@/lib/zimlii-scraper';
import { getCategories } from '@/lib/zimlii-scraper';
import { cache, CACHE_TTL } from '@/lib/cache';

const CACHE_KEY = 'api:stats';
const CACHE_DURATION = CACHE_TTL.ONE_HOUR;

function computeStats() {
  const allDocs = getAllSampleDocuments();
  const categories = getCategories();
  const courts = getCourtsList();

  // Sort by date descending and take the 5 most recent
  const recentDocuments = [...allDocs]
    .filter((doc) => doc.date)
    .sort((a, b) => new Date(b.date!).getTime() - new Date(a.date!).getTime())
    .slice(0, 5);

  return {
    totalDocuments: allDocs.length,
    categoriesCount: categories.length,
    courtsCount: courts.length,
    recentDocuments,
    courtsList: courts,
  };
}

export async function GET() {
  // Check cache first
  const cached = cache.get<ReturnType<typeof computeStats>>(CACHE_KEY);
  if (cached) {
    return NextResponse.json({
      ...cached,
      cached: true,
    });
  }

  try {
    const stats = computeStats();

    // Cache for 1 hour
    cache.set(CACHE_KEY, stats, CACHE_DURATION);

    return NextResponse.json({
      ...stats,
      cached: false,
    });
  } catch (error) {
    console.error('Stats API error:', error);
    return NextResponse.json(
      {
        error: 'Failed to retrieve statistics',
        message: 'An error occurred while computing database statistics.',
      },
      { status: 500 }
    );
  }
}
