import { NextResponse } from 'next/server';
import { getCategories } from '@/lib/zimlii-scraper';

export async function GET() {
  const categories = getCategories();
  return NextResponse.json({
    categories,
    total: categories.length,
    timestamp: new Date().toISOString(),
  });
}
