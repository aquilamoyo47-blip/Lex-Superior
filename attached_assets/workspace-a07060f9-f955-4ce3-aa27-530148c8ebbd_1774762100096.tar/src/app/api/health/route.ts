import { NextResponse } from 'next/server';
import { getHealthStatus } from '@/lib/zimlii-scraper';

export async function GET() {
  return NextResponse.json(getHealthStatus());
}
