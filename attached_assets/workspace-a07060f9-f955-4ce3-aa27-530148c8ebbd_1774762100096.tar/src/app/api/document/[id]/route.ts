import { NextRequest, NextResponse } from 'next/server';
import { getDocumentDetail } from '@/lib/zimlii-scraper';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;

  if (!id) {
    return NextResponse.json(
      {
        error: 'Document ID is required',
        message: 'Please provide a valid document ID or URL',
      },
      { status: 400 }
    );
  }

  try {
    const document = await getDocumentDetail(decodeURIComponent(id));
    return NextResponse.json(document);
  } catch (error) {
    console.error('Document API error:', error);
    return NextResponse.json(
      {
        error: 'Document retrieval failed',
        message: 'An error occurred while retrieving the document. Please try again later.',
      },
      { status: 500 }
    );
  }
}
