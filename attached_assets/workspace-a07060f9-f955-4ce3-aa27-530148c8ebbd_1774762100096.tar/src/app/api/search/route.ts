import { NextRequest, NextResponse } from 'next/server';
import { searchDocuments } from '@/lib/zimlii-scraper';
import { ZIMLII_CONFIG } from '@/lib/zimlii-config';
import type { SortOption } from '@/lib/zimlii-scraper';

const VALID_SORT_OPTIONS: SortOption[] = ['date-desc', 'date-asc', 'relevance'];

export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;

  const query = searchParams.get('q') || '';
  const category = searchParams.get('category') || undefined;
  const court = searchParams.get('court') || undefined;
  const limitParam = parseInt(searchParams.get('limit') || '10', 10);
  const pageParam = parseInt(searchParams.get('page') || '1', 10);
  const sortParam = searchParams.get('sort') || 'date-desc';
  const dateFrom = searchParams.get('dateFrom') || undefined;
  const dateTo = searchParams.get('dateTo') || undefined;

  // Validate and clamp parameters
  const limit = Math.min(Math.max(1, limitParam), ZIMLII_CONFIG.MAX_LIMIT);
  const page = Math.max(1, pageParam);

  // Validate sort option
  const sort: SortOption = VALID_SORT_OPTIONS.includes(sortParam as SortOption)
    ? (sortParam as SortOption)
    : 'date-desc';

  // Validate date strings if provided
  if (dateFrom && isNaN(new Date(dateFrom).getTime())) {
    return NextResponse.json(
      {
        error: 'Invalid dateFrom parameter',
        message: 'dateFrom must be a valid ISO date string (e.g., 2023-01-01)',
      },
      { status: 400 }
    );
  }

  if (dateTo && isNaN(new Date(dateTo).getTime())) {
    return NextResponse.json(
      {
        error: 'Invalid dateTo parameter',
        message: 'dateTo must be a valid ISO date string (e.g., 2024-12-31)',
      },
      { status: 400 }
    );
  }

  // Require at least a query or category
  if (!query && !category) {
    return NextResponse.json(
      {
        error: 'At least a query (q) or category is required',
        message: 'Please provide a search query using the "q" parameter',
      },
      { status: 400 }
    );
  }

  try {
    const results = await searchDocuments(query, {
      category,
      court,
      limit,
      page,
      sort,
      dateFrom,
      dateTo,
    });
    return NextResponse.json(results);
  } catch (error) {
    console.error('Search API error:', error);
    return NextResponse.json(
      {
        error: 'Search failed',
        message: 'An error occurred while searching. Please try again later.',
      },
      { status: 500 }
    );
  }
}
